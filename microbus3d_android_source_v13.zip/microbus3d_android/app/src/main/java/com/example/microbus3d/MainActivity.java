package com.example.microbus3d;

import android.app.Activity;
import android.os.Bundle;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.media.MediaPlayer;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.content.ClipData;
import java.util.ArrayList;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView.Renderer;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import java.util.Random;

public class MainActivity extends Activity {
    private GameView game;
    private final ArrayList<Uri> radioTracks = new ArrayList<>();
    private MediaPlayer radioPlayer;
    private int radioIndex = 0;
    private TextView radioTrackLabel;
    private TextView radioPlayButton;
    private LinearLayout radioPanel;
    private boolean radioPreparing = false;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        game = new GameView(this);
        root.addView(game);

        TextView title = new TextView(this);
        title.setText("ميكروباص مصر 3D");
        title.setTextColor(Color.WHITE); title.setTextSize(14); title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER); title.setSingleLine(true);
        title.setPadding(dp(14),dp(6),dp(14),dp(6));
        title.setBackground(round(0xB820252B));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        tp.topMargin=dp(8); root.addView(title,tp);

        TextView hint = new TextView(this);
        hint.setText("لف الدركسيون للتوجيه  •  بنزين وفرامل  •  فتيس يدوي");
        hint.setTextColor(Color.WHITE); hint.setTextSize(11); hint.setGravity(Gravity.CENTER); hint.setSingleLine(true);
        hint.setPadding(dp(12),dp(5),dp(12),dp(5));
        hint.setBackground(round(0x8020252B));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        hp.bottomMargin=dp(6); root.addView(hint,hp);

        TextView status = new TextView(this);
        status.setText("السرعة: 0 كم/س");
        status.setTextColor(Color.WHITE); status.setTextSize(13); status.setTypeface(null, Typeface.BOLD);
        status.setGravity(Gravity.CENTER); status.setSingleLine(true); status.setPadding(dp(12),dp(6),dp(12),dp(6));
        status.setBackground(round(0xB820252B));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT);
        sp.leftMargin=dp(12); sp.topMargin=dp(8); root.addView(status,sp);
        game.statusLabel = status;

        TextView rpm = new TextView(this);
        rpm.setText("RPM  ▰▱▱▱▱▱");
        rpm.setTextColor(Color.WHITE); rpm.setTextSize(12); rpm.setTypeface(null, Typeface.BOLD);
        rpm.setGravity(Gravity.CENTER); rpm.setSingleLine(true); rpm.setPadding(dp(12),dp(6),dp(12),dp(6));
        rpm.setBackground(round(0xD91B252D));
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        rp.bottomMargin=dp(36); root.addView(rpm,rp);
        game.rpmLabel = rpm;

        TextView gas = new TextView(this);
        gas.setText("بنزين ▲"); gas.setTextColor(Color.WHITE); gas.setTextSize(15); gas.setTypeface(null,Typeface.BOLD);
        gas.setGravity(Gravity.CENTER); gas.setSingleLine(true); gas.setBackground(round(0xDD16834A));
        FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(dp(100),dp(72),Gravity.RIGHT|Gravity.BOTTOM);
        gp.rightMargin=dp(16); gp.bottomMargin=dp(20); root.addView(gas,gp);
        gas.setOnTouchListener((v,e)-> { game.gas = e.getAction()!=MotionEvent.ACTION_UP && e.getAction()!=MotionEvent.ACTION_CANCEL; return true; });

        TextView brake = new TextView(this);
        brake.setText("فرامل ■"); brake.setTextColor(Color.WHITE); brake.setTextSize(13); brake.setTypeface(null,Typeface.BOLD);
        brake.setGravity(Gravity.CENTER); brake.setSingleLine(true); brake.setBackground(round(0xDDAD302A));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(84),dp(60),Gravity.RIGHT|Gravity.BOTTOM);
        bp.rightMargin=dp(124); bp.bottomMargin=dp(20); root.addView(brake,bp);
        brake.setOnTouchListener((v,e)-> { game.brake = e.getAction()!=MotionEvent.ACTION_UP && e.getAction()!=MotionEvent.ACTION_CANCEL; return true; });

        TextView gear = new TextView(this);
        gear.setText("فتيس\nN");
        gear.setTextColor(Color.WHITE); gear.setTextSize(13); gear.setTypeface(null,Typeface.BOLD);
        gear.setGravity(Gravity.CENTER); gear.setBackground(round(0xDD34495E));
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(dp(60),dp(60),Gravity.LEFT|Gravity.BOTTOM);
        fp.leftMargin=dp(16); fp.bottomMargin=dp(30); root.addView(gear,fp);
        gear.setOnClickListener(v -> {
            game.gear = (game.gear + 1) % 4;
            String[] names={"N","1","2","R"};
            gear.setText("فتيس\n"+names[game.gear]);
        });

        TextView wheel = new TextView(this);
        wheel.setText("◉");
        wheel.setTextColor(Color.WHITE); wheel.setTextSize(44); wheel.setGravity(Gravity.CENTER);
        wheel.setBackground(round(0xAA273746));
        FrameLayout.LayoutParams wp = new FrameLayout.LayoutParams(dp(100),dp(100),Gravity.LEFT|Gravity.BOTTOM);
        wp.leftMargin=dp(88); wp.bottomMargin=dp(30); root.addView(wheel,wp);
        wheel.setOnTouchListener((v,e) -> {
            if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE) {
                float center=v.getWidth()/2f;
                float dx=(e.getX()-center)/center;
                game.steer=Math.max(-1f,Math.min(1f,dx));
            } else if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL) game.steer=0;
            return true;
        });

        LinearLayout topButtons = new LinearLayout(this);
        topButtons.setOrientation(LinearLayout.HORIZONTAL);
        FrameLayout.LayoutParams tbp = new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.RIGHT);
        tbp.rightMargin=dp(12); tbp.topMargin=dp(8); root.addView(topButtons,tbp);

        TextView camera = new TextView(this);
        camera.setText("📷 خارجية");
        camera.setTextColor(Color.WHITE); camera.setTextSize(12); camera.setTypeface(null,Typeface.BOLD);
        camera.setGravity(Gravity.CENTER); camera.setSingleLine(true); camera.setPadding(dp(12),dp(8),dp(12),dp(8));
        camera.setBackground(round(0xDD34495E));
        topButtons.addView(camera,new LinearLayout.LayoutParams(-2,-2));
        camera.setOnClickListener(v -> {
            game.renderer.interiorCamera = !game.renderer.interiorCamera;
            camera.setText(game.renderer.interiorCamera ? "📷 داخلية" : "📷 خارجية");
        });

        TextView radioToggle = new TextView(this);
        radioToggle.setText("♫ الراديو");
        radioToggle.setTextColor(Color.WHITE); radioToggle.setTextSize(12); radioToggle.setTypeface(null,Typeface.BOLD);
        radioToggle.setGravity(Gravity.CENTER); radioToggle.setSingleLine(true); radioToggle.setPadding(dp(12),dp(8),dp(12),dp(8));
        radioToggle.setBackground(round(0xDD176B45));
        LinearLayout.LayoutParams rtp = new LinearLayout.LayoutParams(-2,-2);
        rtp.leftMargin=dp(8); topButtons.addView(radioToggle,rtp);

        radioPanel = new LinearLayout(this);
        radioPanel.setOrientation(LinearLayout.VERTICAL);
        radioPanel.setPadding(dp(10),dp(8),dp(10),dp(8));
        radioPanel.setGravity(Gravity.CENTER);
        radioPanel.setBackground(round(0xEE17242B));
        radioPanel.setVisibility(View.GONE);
        FrameLayout.LayoutParams rpp = new FrameLayout.LayoutParams(dp(250),-2,Gravity.TOP|Gravity.RIGHT);
        rpp.rightMargin=dp(12); rpp.topMargin=dp(52); root.addView(radioPanel,rpp);

        TextView radioTitle = new TextView(this);
        radioTitle.setText("📻 راديو الميكروباص");
        radioTitle.setTextColor(0xFFFFD166); radioTitle.setTextSize(14); radioTitle.setTypeface(null,Typeface.BOLD);
        radioTitle.setGravity(Gravity.CENTER); radioTitle.setSingleLine(true);
        radioPanel.addView(radioTitle,new LinearLayout.LayoutParams(-1,-2));

        radioTrackLabel = new TextView(this);
        radioTrackLabel.setText("اختار أغاني من موبايلك");
        radioTrackLabel.setTextColor(Color.WHITE); radioTrackLabel.setTextSize(11);
        radioTrackLabel.setGravity(Gravity.CENTER); radioTrackLabel.setPadding(dp(4),dp(6),dp(4),dp(6));
        radioPanel.addView(radioTrackLabel,new LinearLayout.LayoutParams(-1,-2));

        TextView chooseTracks = new TextView(this);
        chooseTracks.setText("＋ اختيار أغاني");
        chooseTracks.setTextColor(Color.WHITE); chooseTracks.setTextSize(12); chooseTracks.setGravity(Gravity.CENTER); chooseTracks.setSingleLine(true);
        chooseTracks.setPadding(dp(8),dp(8),dp(8),dp(8)); chooseTracks.setBackground(round(0xFF287D55));
        LinearLayout.LayoutParams ctp = new LinearLayout.LayoutParams(-1,-2);
        ctp.bottomMargin=dp(6); radioPanel.addView(chooseTracks,ctp);
        chooseTracks.setOnClickListener(v -> {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.setType("audio/*");
            pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(pick,"اختار ملفات الأغاني"),4201);
        });

        LinearLayout radioControls = new LinearLayout(this);
        radioControls.setOrientation(LinearLayout.HORIZONTAL);
        radioControls.setGravity(Gravity.CENTER);
        radioPanel.addView(radioControls,new LinearLayout.LayoutParams(-1,-2));
        TextView previousTrack = radioButton("⏮",0xFF34495E);
        radioControls.addView(previousTrack,new LinearLayout.LayoutParams(0,dp(40),1));
        TextView playPause = radioButton("▶",0xFF176B45);
        radioPlayButton = playPause;
        LinearLayout.LayoutParams playLp = new LinearLayout.LayoutParams(0,dp(40),1);
        playLp.leftMargin=dp(6); playLp.rightMargin=dp(6); radioControls.addView(playPause,playLp);
        TextView nextTrack = radioButton("⏭",0xFF34495E);
        radioControls.addView(nextTrack,new LinearLayout.LayoutParams(0,dp(40),1));
        previousTrack.setOnClickListener(v -> changeRadioTrack(-1));
        nextTrack.setOnClickListener(v -> changeRadioTrack(1));
        playPause.setOnClickListener(v -> toggleRadioPlayback());

        TextView closeRadio = new TextView(this);
        closeRadio.setText("إغلاق");
        closeRadio.setTextColor(0xFFCCD6DD); closeRadio.setTextSize(12); closeRadio.setGravity(Gravity.CENTER);
        closeRadio.setPadding(dp(8),dp(8),dp(8),dp(2));
        radioPanel.addView(closeRadio,new LinearLayout.LayoutParams(-1,-2));
        closeRadio.setOnClickListener(v -> radioPanel.setVisibility(View.GONE));
        radioToggle.setOnClickListener(v -> radioPanel.setVisibility(radioPanel.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));

        setContentView(root);
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView radioButton(String text, int color) {
        TextView button = new TextView(this);
        button.setText(text); button.setTextColor(Color.WHITE); button.setTextSize(12);
        button.setTypeface(null,Typeface.BOLD); button.setGravity(Gravity.CENTER);
        button.setPadding(dp(4),dp(6),dp(4),dp(6)); button.setBackground(round(color));
        return button;
    }

    private void toggleRadioPlayback() {
        if (radioTracks.isEmpty()) {
            Toast.makeText(this,"اختار أغاني الأول من زر اختيار أغاني",Toast.LENGTH_SHORT).show();
            return;
        }
        if (radioPlayer != null && radioPlayer.isPlaying()) {
            radioPlayer.pause();
            radioPlayButton.setText("▶");
            return;
        }
        if (radioPlayer != null && !radioPreparing) {
            try { radioPlayer.start(); radioPlayButton.setText("⏸"); }
            catch (Exception e) { playRadioTrack(radioIndex); }
        } else {
            playRadioTrack(radioIndex);
        }
    }

    private void changeRadioTrack(int delta) {
        if (radioTracks.isEmpty()) {
            Toast.makeText(this,"اختار أغاني الأول",Toast.LENGTH_SHORT).show();
            return;
        }
        radioIndex = (radioIndex + delta + radioTracks.size()) % radioTracks.size();
        playRadioTrack(radioIndex);
    }

    private void playRadioTrack(int index) {
        if (radioTracks.isEmpty()) return;
        radioIndex = (index + radioTracks.size()) % radioTracks.size();
        if (radioPlayer != null) {
            try { radioPlayer.stop(); } catch (Exception ignored) {}
            try { radioPlayer.release(); } catch (Exception ignored) {}
            radioPlayer = null;
        }
        radioPreparing = true;
        Uri uri = radioTracks.get(radioIndex);
        String name = "أغنية " + (radioIndex+1) + " / " + radioTracks.size();
        radioTrackLabel.setText("جاري تجهيز " + name);
        radioPlayButton.setText("…");
        try {
            radioPlayer = new MediaPlayer();
            radioPlayer.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            radioPlayer.setDataSource(this,uri);
            radioPlayer.setOnPreparedListener(mp -> {
                radioPreparing = false;
                mp.start();
                radioPlayButton.setText("⏸");
                radioTrackLabel.setText("تشغيل " + name);
            });
            radioPlayer.setOnCompletionListener(mp -> changeRadioTrack(1));
            radioPlayer.setOnErrorListener((mp,what,extra) -> {
                radioPreparing = false;
                radioTrackLabel.setText("تعذر تشغيل الملف؛ جرّب ملفًا آخر");
                radioPlayButton.setText("▶");
                return true;
            });
            radioPlayer.prepareAsync();
        } catch (Exception e) {
            radioPreparing = false;
            radioTrackLabel.setText("تعذر فتح ملف الصوت");
            radioPlayButton.setText("▶");
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode==4201 && resultCode==RESULT_OK && data!=null) {
            ArrayList<Uri> picked = new ArrayList<>();
            try {
                if (data.getClipData()!=null) {
                    ClipData clips=data.getClipData();
                    for(int i=0;i<clips.getItemCount();i++) picked.add(clips.getItemAt(i).getUri());
                } else if (data.getData()!=null) picked.add(data.getData());
                for(Uri uri:picked) {
                    try { getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                    catch(Exception ignored) {}
                    if(!radioTracks.contains(uri)) radioTracks.add(uri);
                }
                if(!picked.isEmpty()) {
                    radioIndex=Math.max(0,radioTracks.size()-picked.size());
                    radioTrackLabel.setText("تم اختيار "+radioTracks.size()+" أغنية");
                    playRadioTrack(radioIndex);
                }
            } catch(Exception e) {
                Toast.makeText(this,"حصلت مشكلة في اختيار الأغاني",Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override protected void onDestroy() {
        releaseRadioPlayer();
        super.onDestroy();
    }

    private void releaseRadioPlayer() {
        if(radioPlayer!=null) {
            try { radioPlayer.stop(); } catch(Exception ignored) {}
            try { radioPlayer.release(); } catch(Exception ignored) {}
            radioPlayer=null;
        }
        radioPreparing=false;
    }

    @Override protected void onResume() {
        super.onResume();
        if (game != null) { game.onResume(); game.startEngineSound(); }
    }
    @Override protected void onPause() {
        if (radioPlayer != null && radioPlayer.isPlaying()) {
            try { radioPlayer.pause(); if (radioPlayButton != null) radioPlayButton.setText("▶"); } catch(Exception ignored) {}
        }
        if (game != null) game.stopEngineSound();
        if (game != null) game.onPause();
        super.onPause();
    }
    GradientDrawable round(int c) { GradientDrawable d=new GradientDrawable(); d.setColor(c); d.setCornerRadius(dp(10)); d.setStroke(Math.max(1,dp(1)),0x88FFFFFF); return d; }

    static class GameView extends GLSurfaceView {
        GameRenderer renderer; volatile boolean gas=false, brake=false; volatile int gear=0; volatile float steer=0; float downX; TextView statusLabel; TextView rpmLabel;
        private EngineSound engineSound;
        GameView(Context c) { super(c); setEGLContextClientVersion(2); renderer=new GameRenderer(this); setRenderer(renderer); setRenderMode(RENDERMODE_CONTINUOUSLY); engineSound = new EngineSound(this); }
        void startEngineSound() { if (engineSound != null) engineSound.start(); }
        void stopEngineSound() { if (engineSound != null) engineSound.stop(); }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getX() < getWidth()*0.52f && e.getY() < getHeight()*0.65f) {
                if(e.getAction()==MotionEvent.ACTION_DOWN) downX=e.getX();
                if(e.getAction()==MotionEvent.ACTION_MOVE) steer=Math.max(-1,Math.min(1,(e.getX()-downX)/(getWidth()*0.18f)));
                if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL) steer=0;
            }
            return true;
        }
    }

    /**
     * Small synthesized engine loop. No audio files or extra permissions are required.
     * Pitch and load follow vehicle speed, throttle, and gear.
     */
    static class EngineSound {
        private final GameView game;
        private volatile boolean running = false;
        private Thread thread;
        private AudioTrack track;
        private static final int SAMPLE_RATE = 22050;
        private static final int BUFFER_SAMPLES = 1024;

        EngineSound(GameView game) { this.game = game; }

        synchronized void start() {
            if (running) return;
            running = true;
            thread = new Thread(this::audioLoop, "MicrobusEngineAudio");
            thread.start();
        }

        synchronized void stop() {
            running = false;
            if (track != null) {
                try { track.pause(); track.flush(); } catch (Exception ignored) {}
            }
            if (thread != null) {
                try { thread.join(250); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                thread = null;
            }
            if (track != null) {
                try { track.stop(); } catch (Exception ignored) {}
                try { track.release(); } catch (Exception ignored) {}
                track = null;
            }
        }

        private void audioLoop() {
            int min = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT);
            int bytes = Math.max(min, BUFFER_SAMPLES * 2 * 4);
            AudioTrack local = null;
            try {
                AudioAttributes attrs = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
                AudioFormat format = new AudioFormat.Builder()
                        .setSampleRate(SAMPLE_RATE)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build();
                local = new AudioTrack(attrs, format, bytes, AudioTrack.MODE_STREAM,
                        android.media.AudioManager.AUDIO_SESSION_ID_GENERATE);
                track = local;
                local.setVolume(0.62f);
                local.play();

                short[] samples = new short[BUFFER_SAMPLES];
                double phase = 0.0;
                double phase2 = 0.0;
                while (running) {
                    float speed = Math.abs(game.renderer.speed);
                    boolean throttle = game.gas;
                    int gear = game.gear;
                    // Idle rumble with a stronger rev when accelerating; neutral can rev too.
                    double rpmFactor = Math.min(1.0, speed / 20.0);
                    double baseHz = 62.0 + rpmFactor * 78.0 + (throttle ? 38.0 : 0.0);
                    if (gear == 0 && throttle) baseHz += 22.0;
                    if (gear == 3) baseHz = Math.max(48.0, baseHz * 0.82);
                    double wobble = throttle ? 2.8 : 1.0;
                    double gain = 0.16 + (throttle ? 0.08 : 0.0);
                    if (game.brake && speed > 1.0f) gain *= 0.88;

                    for (int i = 0; i < samples.length; i++) {
                        double hz = baseHz + Math.sin(phase2) * wobble;
                        phase += 2.0 * Math.PI * hz / SAMPLE_RATE;
                        phase2 += 2.0 * Math.PI * 3.1 / SAMPLE_RATE;
                        if (phase > Math.PI * 2.0) phase -= Math.PI * 2.0;
                        if (phase2 > Math.PI * 2.0) phase2 -= Math.PI * 2.0;
                        // A few harmonics make the tone less like a pure beep.
                        double tone = Math.sin(phase) * 0.72
                                + Math.sin(phase * 2.0) * 0.20
                                + Math.sin(phase * 3.0) * 0.08;
                        // Gentle low-frequency vibration.
                        tone += Math.sin(phase * 0.5) * 0.08;
                        samples[i] = (short) (Math.max(-1.0, Math.min(1.0, tone * gain)) * 32767);
                    }
                    int written = local.write(samples, 0, samples.length);
                    if (written < 0) break;
                }
            } catch (Exception ignored) {
                // Audio is optional: gameplay should continue if the device audio API fails.
            } finally {
                if (local != null) {
                    try { local.pause(); } catch (Exception ignored) {}
                    try { local.flush(); } catch (Exception ignored) {}
                    try { local.release(); } catch (Exception ignored) {}
                }
                track = null;
                running = false;
            }
        }
    }

    static class GameRenderer implements Renderer {
        GameView view; int program; int posLoc,normLoc=-1,colLoc,mvpLoc,modelLoc=-1; float[] outM=new float[16]; FloatBuffer cube; float[] projection=new float[16], viewM=new float[16], model=new float[16], mvp=new float[16];
        float distance=0, lateral=0; volatile float speed=0; volatile boolean interiorCamera=false; long last=System.nanoTime();
        float collisionCooldown=0; long collisionUntil=0;
        float suspensionImpulse=0f;
        float trafficLightClock=0f;
        FloatBuffer cylMesh, wedgeMesh; int cylCount, wedgeCount;
        GameRenderer(GameView v){view=v; cube=makeCube(); cylMesh=makeCylinder(14); wedgeMesh=makeWedge();}
        public void onSurfaceCreated(GL10 gl,EGLConfig cfg) {
            GLES20.glClearColor(0.66f,0.82f,0.95f,1); GLES20.glEnable(GLES20.GL_DEPTH_TEST);
            String vs="attribute vec3 aPos; attribute vec3 aNrm; uniform mat4 uMVP; uniform mat4 uModel; varying vec3 vN; varying float vD; void main(){ gl_Position=uMVP*vec4(aPos,1.0); vN=(uModel*vec4(aNrm,0.0)).xyz; vD=gl_Position.w; }";
            String fs="precision mediump float; uniform vec4 uColor; varying vec3 vN; varying float vD; void main(){ vec3 L=normalize(vec3(-0.45,0.85,0.35)); float d=max(dot(normalize(vN),L),0.0); vec3 c=uColor.rgb*(0.58+0.50*d); float f=clamp((vD-45.0)/175.0,0.0,1.0); c=mix(c,vec3(0.66,0.82,0.95),f*f); gl_FragColor=vec4(c,1.0); }";
            int p=buildProgram(vs,fs);
            if(p==0) {
                String vs2="attribute vec3 aPos; uniform mat4 uMVP; void main(){gl_Position=uMVP*vec4(aPos,1.0);}";
                String fs2="precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}";
                p=buildProgram(vs2,fs2);
            }
            program=p;
            posLoc=GLES20.glGetAttribLocation(program,"aPos"); normLoc=GLES20.glGetAttribLocation(program,"aNrm");
            colLoc=GLES20.glGetUniformLocation(program,"uColor"); mvpLoc=GLES20.glGetUniformLocation(program,"uMVP"); modelLoc=GLES20.glGetUniformLocation(program,"uModel");
        }
        int buildProgram(String vs,String fs){
            int a=shader(GLES20.GL_VERTEX_SHADER,vs), b=shader(GLES20.GL_FRAGMENT_SHADER,fs);
            if(a==0||b==0) return 0;
            int pr=GLES20.glCreateProgram(); GLES20.glAttachShader(pr,a); GLES20.glAttachShader(pr,b); GLES20.glLinkProgram(pr);
            int[] ok=new int[1]; GLES20.glGetProgramiv(pr,GLES20.GL_LINK_STATUS,ok,0);
            return ok[0]==0 ? 0 : pr;
        }
        int shader(int type,String src){int sh=GLES20.glCreateShader(type);GLES20.glShaderSource(sh,src);GLES20.glCompileShader(sh);int[] ok=new int[1];GLES20.glGetShaderiv(sh,GLES20.GL_COMPILE_STATUS,ok,0);return ok[0]==0?0:sh;}
        public void onSurfaceChanged(GL10 gl,int w,int h){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(projection,0,60f,(float)w/Math.max(1,h),0.1f,250f);}
        public void onDrawFrame(GL10 gl){
            long now=System.nanoTime(); float dt=Math.min(.05f,(now-last)/1e9f); last=now;
            float routeProgressForPhysics = Math.max(0f, distance);
            boolean inCity = routeProgressForPhysics < 185f;
            float maxSpeed = view.gear==1 ? (inCity?6.5f:9f) : view.gear==2 ? (inCity?12f:19f) : view.gear==3 ? 5f : 0f;
            if(view.gear==3) {
                if(view.gas) speed=Math.max(-5f,speed-dt*4.5f); else speed=Math.min(0,speed+dt*2f);
            } else if(view.gear==0) {
                speed=Math.max(0,speed-dt*3f);
            } else if(view.gas) speed=Math.min(maxSpeed,speed+dt*(view.gear==1?4.0f:6.0f));
            else speed=Math.max(0,speed-dt*1.2f);
            if(view.brake) {
                speed = speed>0 ? Math.max(0,speed-dt*18f) : Math.min(0,speed+dt*18f);
                suspensionImpulse = Math.min(1.0f, suspensionImpulse + dt*1.7f);
            }
            suspensionImpulse = Math.max(0f, suspensionImpulse-dt*1.8f);
            collisionCooldown = Math.max(0f, collisionCooldown-dt);
            for(int i=0;i<9;i++) {
                float tz = -18f - i*21f + (float)(((distance*(0.65f + (i%3)*0.18f) + i*7f) % 150f));
                if(tz > 8f) tz -= 150f;
                float lane = (i%3==0) ? -2.45f : ((i%3==1) ? 2.45f : 0.15f);
                if(Math.abs(tz-1.1f)<2.4f && Math.abs(lateral-lane)<1.45f && Math.abs(speed)>2.0f && collisionCooldown<=0f) {
                    speed = Math.max(0f, speed*0.52f);
                    suspensionImpulse = 1.0f;
                    lateral += (lateral <= lane ? -0.35f : 0.35f);
                    lateral=Math.max(-3.1f,Math.min(3.1f,lateral));
                    collisionUntil=System.currentTimeMillis()+1400;
                    collisionCooldown=1.1f;
                }
            }
            // Slightly heavier, slower steering in town; more stable at highway speed.
            distance += speed*dt;
            float steerResponse = inCity ? 4.25f : 3.65f;
            lateral += view.steer*dt*steerResponse*(1.0f-Math.min(0.42f,Math.abs(speed)/48f));
            lateral=Math.max(-3.1f,Math.min(3.1f,lateral));
            // Traffic signals: slow the bus near a red light in the Cairo section.
            trafficLightClock += dt;
            if (inCity && trafficLightClock % 28f > 0.5f && trafficLightClock % 28f < 5.5f
                    && Math.abs(distance % 70f) < 1.5f && speed > 3.0f) {
                speed = Math.max(2.0f, speed-dt*5.5f);
            }
            // City speed humps take a little momentum off the microbus.
            if (inCity && Math.abs(speed)>2.0f) {
                float humpPhase = (Math.abs(distance)+24f)%32f;
                if (humpPhase < 0.55f && collisionCooldown<=0f) {
                    speed *= 0.90f;
                    suspensionImpulse = Math.max(suspensionImpulse,0.48f);
                    collisionCooldown = 0.45f;
                }
            }
            if(view.statusLabel!=null) {
                final String msg = System.currentTimeMillis()<collisionUntil
                    ? "⚠ خبطة! السرعة: "+Math.max(0,(int)(Math.abs(speed)*5))+" كم/س"
                    : (Math.max(0f,distance)<185f ? "شوارع القاهرة" : Math.max(0f,distance)<280f ? "مخرج القاهرة • الصحراوي" : "طريق إسكندرية الصحراوي")
                      +"  •  "+Math.max(0,(int)(Math.abs(speed)*5))+" كم/س  •  "+(view.gear==0?"N":view.gear==1?"1":view.gear==2?"2":"R");
                view.statusLabel.post(() -> view.statusLabel.setText(msg));
            }
            if(view.rpmLabel!=null) {
                float throttleLoad = view.gas ? 0.28f : 0f;
                float rpmValue = Math.min(1f, 0.12f + Math.abs(speed)/22f + throttleLoad);
                int bars = Math.max(1, Math.min(6, Math.round(rpmValue*6f)));
                StringBuilder meter = new StringBuilder("RPM  ");
                for(int k=0;k<6;k++) meter.append(k<bars ? "▰" : "▱");
                final String rpmText = meter.toString() + "  " + (int)(850 + rpmValue*3850) + " دورة/دقيقة";
                view.rpmLabel.post(() -> view.rpmLabel.setText(rpmText));
            }
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT); GLES20.glUseProgram(program);
            if(interiorCamera) {
                // Driver-eye camera: lower and closer to the windshield.
                Matrix.setLookAtM(viewM,0,lateral+0.0f,2.15f,2.1f,lateral,1.65f,-12.0f,0,1,0);
            } else {
                Matrix.setLookAtM(viewM,0,lateral+0.0f,5.2f,10.5f,lateral,1.0f,-3.0f,0,1,0);
            }
            // Egyptian route: busy Cairo streets fade into the sandy Alexandria desert road.
            float routeProgress = Math.max(0f, distance);
            float urban = routeProgress < 170f ? 1f : routeProgress < 280f ? (280f-routeProgress)/110f : 0f;
            float gR = 0.78f - urban*0.30f, gG = 0.68f - urban*0.24f, gB = 0.49f - urban*0.07f;
            gdraw(0,-1.0f,-100,320,0.15f,320,gR,gG,gB);
            float roadHalf = 4.75f - urban*0.45f;
            gdraw(0,-0.82f,-100,roadHalf*2f,0.18f,320,0.19f,0.20f,0.21f);
            gdraw(-roadHalf-0.55f,-0.79f,-100,1.0f,0.13f,320,urban*0.52f+0.20f,urban*0.49f+0.22f,urban*0.43f+0.22f);
            gdraw(roadHalf+0.55f,-0.79f,-100,1.0f,0.13f,320,urban*0.52f+0.20f,urban*0.49f+0.22f,urban*0.43f+0.22f);
            if (urban > 0.05f) {
                gdraw(-roadHalf-1.05f,-0.67f,-100,0.85f,0.18f,320,0.57f,0.54f,0.48f);
                gdraw( roadHalf+1.05f,-0.67f,-100,0.85f,0.18f,320,0.57f,0.54f,0.48f);
                for (int c=0;c<28;c++) {
                    float cz=-c*8f+(((distance%8f)+8f)%8f);
                    float curbColor=(c%2==0)?0.82f:0.72f;
                    gdraw(-roadHalf-1.05f,-0.55f,cz,0.80f,0.06f,1.8f,curbColor,0.75f,0.62f);
                    gdraw( roadHalf+1.05f,-0.55f,cz,0.80f,0.06f,1.8f,curbColor,0.75f,0.62f);
                }
            }
            float offset=((distance%12)+12)%12;
            for(int i=0;i<22;i++){float z=-i*10+(offset); gdraw(0,-0.70f,z,0.13f,0.035f,4.3f,0.94f,0.88f,0.63f);}
            if (urban > 0.15f) {
                gdraw(-1.72f,-0.695f,-100,0.07f,0.025f,320,0.88f,0.78f,0.46f);
                gdraw( 1.72f,-0.695f,-100,0.07f,0.025f,320,0.88f,0.78f,0.46f);
            }
            if (urban < 0.3f) {
                for(int marker=0;marker<18;marker++) {
                    float mz=-marker*12f+(((distance%12f)+12f)%12f);
                    gdraw(-4.50f,-0.69f,mz,0.12f,0.035f,0.22f,0.93f,0.84f,0.52f);
                    gdraw( 4.50f,-0.69f,mz,0.12f,0.035f,0.22f,0.93f,0.84f,0.52f);
                }
            }
            // Traffic mix inspired by Egypt: Cairo black/white taxis, private sedans,
            // white-and-green microbuses and small delivery vans.
            for(int i=0;i<11;i++){
                float z = -16f - i*17.5f + (float)(((distance*(0.62f + (i%3)*0.16f) + i*9f) % 165f));
                if(z > 9f) z -= 165f;
                float lane = (i%3==0) ? -2.45f : ((i%3==1) ? 2.45f : 0.15f);
                if(Math.abs(z-1.1f)<12f && Math.abs(lateral-lane)<2.0f) lane += (lane <= lateral ? -1.0f : 1.0f);
                float tx = lane + (float)Math.sin(distance*0.012f+i*1.7f)*0.18f;
                int type = (i%5==0) ? 1 : (i%5==2) ? 2 : (i%5==4) ? 3 : 0;
                float[] pal = {0.18f,0.22f,0.25f, 0.70f,0.72f,0.78f, 0.62f,0.12f,0.12f, 0.15f,0.30f,0.52f, 0.85f,0.85f,0.82f, 0.30f,0.42f,0.28f};
                int pi = ((i*7+3)%6)*3;
                float cr = type==1 ? 0.92f : type==2 ? 0.90f : type==3 ? 0.80f : pal[pi];
                float cg = type==1 ? 0.91f : type==2 ? 0.92f : type==3 ? 0.82f : pal[pi+1];
                float cb = type==1 ? 0.86f : type==2 ? 0.84f : type==3 ? 0.76f : pal[pi+2];
                trafficCar(tx,z,type,cr,cg,cb);
            }
            // Roadside scenery with stable world ids: style and side never change as slots scroll past.
            final float SP = 14f;
            int sBase = (int)Math.floor(distance / SP);
            float sFrac = distance - sBase * SP;
            for (int k = 0; k < 16; k++) {
                int id = k + sBase;
                float zc = -k * SP + sFrac;
                float along = id * SP;
                float u = along < 170f ? 1f : along < 280f ? (280f - along) / 110f : 0f;
                for (int sd = 0; sd < 2; sd++) {
                    float sgn = sd == 0 ? -1f : 1f;
                    int hh = hash2(id, sd);
                    float zs = zc - (sd == 1 ? 7f : 0f);
                    if (u > 0.12f) {
                        buildingBlock(sgn, zs, hh, k < 5);
                        lamp(sgn * 5.7f, zs + 7f, sgn);
                    } else {
                        desertSide(sgn, zs, hh);
                    }
                }
            }
            if (urban > 0.15f) {
                float crossZ=-32f+(((distance%70f)+70f)%70f);
                if(crossZ>8f) crossZ-=70f;
                for(int stripe=0;stripe<9;stripe++) {
                    gdraw(-3.5f+stripe*0.88f,-0.685f,crossZ,0.55f,0.025f,1.15f,0.88f,0.87f,0.80f);
                }
                float signalPhase=trafficLightClock%12f;
                float red=signalPhase<5.5f?0.95f:0.16f;
                float amber=(signalPhase>=5.5f&&signalPhase<7f)?0.95f:0.18f;
                float green=signalPhase>=7f?0.88f:0.14f;
                draw(-5.25f,2.25f,crossZ,0.12f,4.4f,0.12f,0.23f,0.24f,0.22f);
                draw(-5.25f,4.35f,crossZ,0.40f,0.86f,0.25f,0.10f,0.11f,0.10f);
                draw(-5.25f,4.58f,crossZ+0.15f,0.22f,0.20f,0.04f,red,0.08f,0.05f);
                draw(-5.25f,4.32f,crossZ+0.15f,0.22f,0.20f,0.04f,amber,amber*0.48f,0.04f);
                draw(-5.25f,4.06f,crossZ+0.15f,0.22f,0.20f,0.04f,0.05f,green,0.08f);
            }
            float signZ=-48f+(((distance%95f)+95f)%95f);
            if (signZ>5f) signZ-=95f;
            if (signZ < -8f) {
                draw(-5.4f,2.1f,signZ,0.16f,4.8f,0.18f,0.62f,0.62f,0.57f);
                draw( 5.4f,2.1f,signZ,0.16f,4.8f,0.18f,0.62f,0.62f,0.57f);
                draw(0,4.5f,signZ,11.4f,1.15f,0.22f,0.06f,0.35f,0.20f);
                draw(0,4.5f,signZ+0.14f,10.8f,0.82f,0.05f,0.10f,0.43f,0.25f);
            }
            if (urban > 0.5f) {
                for(int hb=0;hb<3;hb++) {
                    float hz=-24f-hb*32f+(((distance%32f)+32f)%32f);
                    gdraw(0,-0.69f,hz,roadHalf*1.7f,0.045f,0.42f,0.77f,0.72f,0.60f);
                    for(int stripe=0;stripe<7;stripe++)
                        gdraw(-roadHalf*0.78f+stripe*roadHalf*0.26f,-0.66f,hz-0.02f,0.42f,0.025f,0.44f,0.12f,0.13f,0.13f);
                }
            }
            // Main player microbus: Egyptian white body, green stripe, chrome details,
            // front grille, mirrors, windows, door seams, yellow plate and moving suspension.
            float suspensionBob = (float)Math.sin(distance*1.25f)*Math.min(0.045f,Math.abs(speed)*0.0018f)
                    + (float)Math.sin(distance*0.42f)*0.018f - suspensionImpulse*0.055f;
            float busY = 0.65f + suspensionBob;
            float busRoll = -view.steer*2.4f*(Math.min(1f,Math.abs(speed)/10f));
            drawRotated(lateral,busY,1.1f,1.55f,1.05f,2.7f,0.91f,0.90f,0.82f,0,0,busRoll);
            drawRotated(lateral,1.05f+suspensionBob,0.35f,1.43f,0.22f,1.95f,0.12f,0.43f,0.26f,0,0,busRoll);
            // Split windshield with dark rubber border and a pair of wiper blades.
            draw(lateral,1.42f+suspensionBob,0.48f,-0.04f,1.2f,0.30f,0.12f,0.22f,0.27f);
            draw(lateral-0.30f,1.43f+suspensionBob,0.12f,0.54f,0.24f,0.035f,0.27f,0.43f,0.49f);
            draw(lateral+0.30f,1.43f+suspensionBob,0.12f,0.54f,0.24f,0.035f,0.27f,0.43f,0.49f);
            draw(lateral-0.28f,1.27f+suspensionBob,0.13f,0.48f,0.035f,0.035f,0.08f,0.09f,0.09f);
            draw(lateral+0.28f,1.27f+suspensionBob,0.13f,0.48f,0.035f,0.035f,0.08f,0.09f,0.09f);
            // Side passenger windows and sliding-door outline.
            for(int side=-1;side<=1;side+=2) {
                draw(lateral+side*0.785f,1.02f+suspensionBob,0.45f,0.055f,0.44f,0.62f,0.17f,0.32f,0.39f);
                draw(lateral+side*0.785f,1.02f+suspensionBob,-0.28f,0.055f,0.44f,0.62f,0.17f,0.32f,0.39f);
                draw(lateral+side*0.80f,0.63f+suspensionBob,-0.10f,0.035f,0.64f,0.04f,0.40f,0.39f,0.33f);
                draw(lateral+side*0.80f,0.65f+suspensionBob,0.70f,0.035f,0.66f,0.04f,0.40f,0.39f,0.33f);
                draw(lateral+side*0.82f,0.82f+suspensionBob,0.05f,0.06f,0.05f,0.14f,0.70f,0.68f,0.58f);
            }
            // Roof sign, mirror arms and mirror housings.
            draw(lateral,1.47f+suspensionBob,1.15f,0.72f,0.16f,0.24f,0.94f,0.94f,0.90f);
            draw(lateral,1.49f+suspensionBob,1.15f,0.56f,0.035f,0.18f,0.12f,0.43f,0.26f);
            draw(lateral-0.90f,1.05f+suspensionBob,0.10f,0.42f,0.06f,0.08f,0.15f,0.15f,0.14f);
            draw(lateral+0.90f,1.05f+suspensionBob,0.10f,0.42f,0.06f,0.08f,0.15f,0.15f,0.14f);
            draw(lateral-1.10f,1.00f+suspensionBob,0.10f,0.24f,0.18f,0.22f,0.09f,0.10f,0.10f);
            draw(lateral+1.10f,1.00f+suspensionBob,0.10f,0.24f,0.18f,0.22f,0.09f,0.10f,0.10f);
            // Front lights, black grille with vertical slats, bumper and Egyptian-style yellow plate.
            draw(lateral-0.92f,0.46f+suspensionBob,-0.24f,0.30f,0.16f,0.06f,0.98f,0.86f,0.50f);
            draw(lateral+0.92f,0.46f+suspensionBob,-0.24f,0.30f,0.16f,0.06f,0.98f,0.86f,0.50f);
            draw(lateral,0.45f+suspensionBob,-0.255f,0.78f,0.24f,0.05f,0.10f,0.11f,0.11f);
            for(int grill=0;grill<5;grill++)
                draw(lateral-0.29f+grill*0.145f,0.45f+suspensionBob,-0.29f,0.025f,0.19f,0.025f,0.48f,0.49f,0.45f);
            draw(lateral,0.20f+suspensionBob,-0.29f,0.60f,0.13f,0.05f,0.90f,0.75f,0.31f);
            draw(lateral,0.12f+suspensionBob,-0.32f,1.30f,0.14f,0.08f,0.18f,0.18f,0.18f);
            // Wheels with hubs; the rotation makes movement more legible.
            float wheelSpin = -distance*160f;
            for(int side=-1;side<=1;side+=2) {
                wheel(lateral+side*0.80f,0.22f+suspensionBob*0.5f,0.35f,0.33f,0.24f,wheelSpin);
                wheel(lateral+side*0.80f,0.22f+suspensionBob*0.5f,1.95f,0.33f,0.24f,wheelSpin);
            }
            draw(lateral,-0.045f,1.1f,1.95f,0.02f,3.15f,0.06f,0.07f,0.08f);
            // Rear of the microbus (the view from the chase camera): window, brake lights, plate, bumper, green band.
            float rearZ = 2.47f;
            boolean braking = view.brake && speed > 0.2f;
            float tl = braking ? 1.0f : 0.60f;
            draw(lateral,1.00f+suspensionBob,rearZ,1.15f,0.42f,0.05f,0.12f,0.20f,0.25f);
            draw(lateral-0.62f,0.62f+suspensionBob,rearZ+0.01f,0.22f,0.30f,0.05f,tl,braking?0.12f:0.05f,0.05f);
            draw(lateral+0.62f,0.62f+suspensionBob,rearZ+0.01f,0.22f,0.30f,0.05f,tl,braking?0.12f:0.05f,0.05f);
            draw(lateral,0.40f+suspensionBob,rearZ+0.02f,0.46f,0.16f,0.05f,0.95f,0.80f,0.25f);
            draw(lateral,0.20f+suspensionBob,rearZ+0.05f,1.50f,0.14f,0.10f,0.20f,0.20f,0.20f);
            draw(lateral,0.76f+suspensionBob,rearZ+0.01f,1.50f,0.12f,0.05f,0.10f,0.43f,0.26f);
            for(int side=-1;side<=1;side+=2)
                draw(lateral+side*0.785f,0.70f+suspensionBob,1.1f,0.04f,0.12f,2.55f,0.10f,0.43f,0.26f);
            draw(lateral,1.20f+suspensionBob,1.3f,1.2f,0.03f,2.0f,0.82f,0.82f,0.76f);
            draw(lateral,1.25f+suspensionBob,1.8f,0.5f,0.07f,0.5f,0.78f,0.78f,0.74f);
            // Driver cabin: dashboard and steering wheel are drawn only in interior view.
            if(interiorCamera) {
                // Dashboard fascia across the lower windshield.
                draw(lateral,0.66f,1.45f,3.35f,0.42f,0.48f,0.08f,0.10f,0.10f);
                draw(lateral,0.90f,1.18f,1.00f,0.13f,0.16f,0.20f,0.22f,0.22f);
                draw(lateral-1.08f,0.73f,1.35f,0.36f,0.08f,0.28f,0.15f,0.17f,0.16f);
                draw(lateral+1.08f,0.73f,1.35f,0.36f,0.08f,0.28f,0.15f,0.17f,0.16f);
                // Center console, vents, radio and gear lever.
                draw(lateral+0.88f,0.54f,1.13f,0.42f,0.30f,0.18f,0.12f,0.13f,0.13f);
                for(int vent=0;vent<4;vent++)
                    draw(lateral+0.75f+vent*0.085f,0.61f,1.02f,0.035f,0.09f,0.025f,0.48f,0.50f,0.46f);
                draw(lateral+0.88f,0.43f,1.02f,0.23f,0.07f,0.025f,0.08f,0.42f,0.25f);
                draw(lateral+0.38f,0.50f,0.76f,0.06f,0.30f,0.06f,0.16f,0.16f,0.15f);
                draw(lateral+0.38f,0.66f,0.76f,0.12f,0.10f,0.12f,0.22f,0.22f,0.20f);
                // Instrument cluster with bright speed/RPM dials.
                draw(lateral-0.55f,1.02f,1.08f,0.28f,0.08f,0.035f,0.03f,0.04f,0.04f);
                draw(lateral-0.55f,1.07f,1.04f,0.19f,0.045f,0.025f,0.08f,0.75f,0.35f);
                draw(lateral+0.02f,1.02f,1.08f,0.28f,0.08f,0.035f,0.03f,0.04f,0.04f);
                draw(lateral+0.02f,1.07f,1.04f,0.19f,0.045f,0.025f,0.95f,0.65f,0.10f);
                // Steering column and simplified steering wheel rim made of small segments.
                draw(lateral-0.02f,0.72f,0.68f,0.12f,0.18f,0.26f,0.06f,0.07f,0.07f);
                for(int k=0;k<12;k++) {
                    double a=k*Math.PI/6.0;
                    float wx=lateral-0.02f+(float)Math.cos(a)*0.63f;
                    float wy=0.83f+(float)Math.sin(a)*0.36f;
                    draw(wx,wy,0.54f,0.10f,0.09f,0.10f,0.035f,0.04f,0.04f);
                }
                draw(lateral-0.02f,0.83f,0.53f,0.12f,0.12f,0.10f,0.05f,0.06f,0.06f);
                // Side pillars frame the windshield.
                draw(lateral-1.58f,1.70f,0.70f,0.10f,1.18f,0.12f,0.08f,0.09f,0.09f);
                draw(lateral+1.58f,1.70f,0.70f,0.10f,1.18f,0.12f,0.08f,0.09f,0.09f);
            }
        }
        void drawRotated(float x,float y,float z,float sx,float sy,float sz,float r,float g,float b,
                         float rx,float ry,float rz) {
            Matrix.setIdentityM(model,0);
            Matrix.translateM(model,0,x,y,z);
            Matrix.rotateM(model,0,rx,1,0,0);
            Matrix.rotateM(model,0,ry,0,1,0);
            Matrix.rotateM(model,0,rz,0,0,1);
            Matrix.scaleM(model,0,sx,sy,sz);
            submit(r,g,b);
        }
        void draw(float x,float y,float z,float sx,float sy,float sz,float r,float g,float b){
            Matrix.setIdentityM(model,0); Matrix.translateM(model,0,x,y,z); Matrix.scaleM(model,0,sx,sy,sz);
            submit(r,g,b);
        }
        void gdraw(float x,float y,float z,float sx,float sy,float sz,float r,float g,float b){
            draw(x,y+0.62f,z,sx,sy,sz,r,g,b);
        }
        void submit(float r,float g,float b){ submitMesh(cube,36,r,g,b); }
        void submitMesh(FloatBuffer mesh,int count,float r,float g,float b){
            Matrix.multiplyMM(mvp,0,viewM,0,model,0); Matrix.multiplyMM(outM,0,projection,0,mvp,0);
            GLES20.glUniformMatrix4fv(mvpLoc,1,false,outM,0);
            if(modelLoc>=0) GLES20.glUniformMatrix4fv(modelLoc,1,false,model,0);
            GLES20.glUniform4f(colLoc,r,g,b,1);
            mesh.position(0);
            GLES20.glEnableVertexAttribArray(posLoc); GLES20.glVertexAttribPointer(posLoc,3,GLES20.GL_FLOAT,false,24,mesh);
            if(normLoc>=0) { mesh.position(3); GLES20.glEnableVertexAttribArray(normLoc); GLES20.glVertexAttribPointer(normLoc,3,GLES20.GL_FLOAT,false,24,mesh); }
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,count);
            GLES20.glDisableVertexAttribArray(posLoc); if(normLoc>=0) GLES20.glDisableVertexAttribArray(normLoc);
            mesh.position(0);
        }
        void drawMesh(FloatBuffer mesh,int count,float x,float y,float z,float sx,float sy,float sz,
                      float r,float g,float b,float rx,float ry,float rz) {
            Matrix.setIdentityM(model,0); Matrix.translateM(model,0,x,y,z);
            Matrix.rotateM(model,0,rx,1,0,0); Matrix.rotateM(model,0,ry,0,1,0); Matrix.rotateM(model,0,rz,0,0,1);
            Matrix.scaleM(model,0,sx,sy,sz);
            submitMesh(mesh,count,r,g,b);
        }
        // Triangular prism: tall at +z, slopes down toward -z (flip=true mirrors it). Used for windshields.
        void wedge(float x,float y,float z,float sx,float sy,float sz,float r,float g,float b,boolean flip){
            drawMesh(wedgeMesh,wedgeCount,x,y,z,sx,sy,sz,r,g,b,0f,flip?180f:0f,0f);
        }
        // Round tire (cylinder along X) with a light rim bar so the spin is visible.
        void wheel(float x,float y,float z,float rad,float w,float spin){
            drawMesh(cylMesh,cylCount,x,y,z,w,rad*2f,rad*2f,0.06f,0.06f,0.065f,spin,0f,0f);
            drawRotated(x,y,z,w*1.08f,rad*0.34f,rad*1.30f,0.62f,0.63f,0.60f,spin,0f,0f);
        }
        static int hash2(int a, int b) {
            int h = a * 73856093 ^ (b * 19349663 + 0x5bd1e995);
            h ^= h >>> 13; h *= 0x27d4eb2d; h ^= h >>> 15;
            return h & 0x7fffffff;
        }
        void lamp(float x, float z, float sgn) {
            draw(x, 1.9f, z, 0.12f, 4.4f, 0.12f, 0.36f, 0.37f, 0.34f);
            draw(x - sgn*0.30f, 4.05f, z, 0.70f, 0.10f, 0.12f, 0.36f, 0.37f, 0.34f);
            draw(x - sgn*0.55f, 3.97f, z, 0.28f, 0.08f, 0.22f, 0.98f, 0.82f, 0.50f);
        }
        void palm(float x, float z) {
            draw(x, 0.85f, z, 0.22f, 2.3f, 0.22f, 0.45f, 0.30f, 0.15f);
            for (int a = 0; a < 4; a++) {
                drawRotated(x, 2.05f, z, 2.1f, 0.06f, 0.44f, 0.16f, 0.42f, 0.17f, 0, a * 45f, 0);
                drawRotated(x, 1.90f, z, 1.5f, 0.05f, 0.36f, 0.21f, 0.48f, 0.19f, 0, a * 45f + 22.5f, 0);
            }
            draw(x, 1.95f, z, 0.30f, 0.22f, 0.30f, 0.36f, 0.24f, 0.11f);
        }
        void desertSide(float sgn, float zc, int h) {
            palm(sgn * (8.0f + (h % 3) * 2.8f), zc + ((h >> 4) % 5) - 2f);
            if (((h >> 3) & 1) == 0) lamp(sgn * 6.9f, zc + 5f, sgn);
            if (((h >> 8) % 3) == 0) {
                draw(sgn * 6.25f, 0.25f, zc - 3f, 0.18f, 1.1f, 0.18f, 0.82f, 0.80f, 0.69f);
                draw(sgn * 6.25f, 0.88f, zc - 3f, 0.62f, 0.28f, 0.18f, 0.10f, 0.42f, 0.27f);
            }
            if (((h >> 10) & 1) == 0) {
                float dh = 2.0f + (h % 3) * 0.9f;
                draw(sgn * (32f + (h % 5) * 6f), -0.6f + dh / 2f, zc, 24f, dh, 20f, 0.75f, 0.63f, 0.43f);
            }
        }
        void buildingBlock(float sgn, float zc, int h, boolean detail) {
            int floors = 4 + h % 4;
            float gf = 1.55f, fh = 1.0f, baseY = -0.3f;
            float H = gf + (floors - 1) * fh + 0.2f;
            float roofY = baseY + H;
            float bx = 4.5f + ((h >> 3) % 3) * 1.0f;
            float bz = 13.7f;
            float front = 6.9f;
            float cx = sgn * (front + bx / 2f);
            float fx = sgn * front;
            float[][] pal = {{0.88f,0.80f,0.64f},{0.82f,0.74f,0.62f},{0.90f,0.72f,0.60f},{0.74f,0.76f,0.72f},
                             {0.92f,0.88f,0.74f},{0.78f,0.60f,0.48f},{0.70f,0.64f,0.58f},{0.86f,0.84f,0.80f}};
            float[] c = pal[(h >> 7) % 8];
            float lr = Math.min(1f, c[0]*1.07f + 0.03f), lg = Math.min(1f, c[1]*1.07f + 0.03f), lb = Math.min(1f, c[2]*1.07f + 0.03f);
            float dr = c[0]*0.72f, dg = c[1]*0.70f, db = c[2]*0.66f;
            // Main mass, shop-level plinth, roof cap and front parapet.
            draw(cx, baseY + H/2f, zc, bx, H, bz, c[0], c[1], c[2]);
            draw(fx - sgn*0.03f, baseY + gf/2f, zc, 0.08f, gf, bz, dr*1.15f, dg*1.15f, db*1.15f);
            draw(cx, roofY + 0.08f, zc, bx + 0.14f, 0.16f, bz + 0.10f, dr, dg, db);
            draw(fx - sgn*0.05f, roofY + 0.30f, zc, 0.10f, 0.30f, bz, lr, lg, lb);
            // Rooftop clutter: water tank, stair shed, satellite dish.
            if ((h >> 14) % 2 == 0) {
                drawMesh(cylMesh, cylCount, cx + sgn*bx*0.22f, roofY + 0.70f, zc + bz*0.22f, 1.0f, 1.2f, 1.2f, 0.62f, 0.64f, 0.62f, 0f, 0f, 90f);
            }
            draw(cx - sgn*bx*0.18f, roofY + 0.40f, zc - bz*0.2f, 0.9f, 0.55f, 0.9f, 0.26f, 0.30f, 0.33f);
            if ((h >> 15) % 3 == 0) {
                drawRotated(cx + sgn*bx*0.1f, roofY + 0.50f, zc - bz*0.3f, 0.5f, 0.05f, 0.5f, 0.85f, 0.85f, 0.82f, 35f, 0f, 0f);
            }
            int nW = 5 + (h >> 9) % 2;
            float sp = bz / nW;
            float z00 = zc - bz/2f + sp*0.5f;
            int style = (h >> 12) % 3;
            for (int f = 1; f < floors; f++) {
                float yb = baseY + gf + (f - 1) * fh;
                draw(fx - sgn*0.06f, yb, zc, 0.12f, 0.08f, bz, lr, lg, lb);
                float wy = yb + 0.52f;
                if (!detail) {
                    draw(fx - sgn*0.03f, wy, zc, 0.07f, 0.50f, bz*0.88f, 0.17f, 0.30f, 0.38f);
                    continue;
                }
                for (int j = 0; j < nW; j++) {
                    float zj = z00 + j * sp;
                    draw(fx - sgn*0.02f, wy, zj, 0.06f, 0.66f, 0.62f, 0.94f, 0.93f, 0.87f);
                    draw(fx - sgn*0.05f, wy, zj, 0.06f, 0.52f, 0.46f, 0.15f, 0.27f, 0.34f);
                    if (style == 2) {
                        draw(fx - sgn*0.06f, wy, zj - 0.38f, 0.04f, 0.58f, 0.16f, 0.25f, 0.42f, 0.28f);
                        draw(fx - sgn*0.06f, wy, zj + 0.38f, 0.04f, 0.58f, 0.16f, 0.25f, 0.42f, 0.28f);
                    }
                    boolean bal = style == 1 ? ((f + j) % 2 == 0) : (((h >> 11) + f + j) % 4 == 0);
                    if (bal) {
                        draw(fx - sgn*0.32f, wy - 0.33f, zj, 0.64f, 0.07f, sp*0.62f, 0.70f, 0.68f, 0.62f);
                        draw(fx - sgn*0.62f, wy - 0.15f, zj, 0.05f, 0.32f, sp*0.62f, 0.20f, 0.23f, 0.23f);
                    } else if (((h >> 4) + f + j) % 6 == 0) {
                        draw(fx - sgn*0.16f, wy - 0.18f, zj + 0.34f, 0.28f, 0.20f, 0.30f, 0.80f, 0.81f, 0.78f);
                    }
                }
            }
            float[][] awn = {{0.82f,0.18f,0.14f},{0.15f,0.45f,0.25f},{0.90f,0.75f,0.20f},{0.20f,0.35f,0.70f}};
            if (detail) {
                for (int j = 0; j < nW; j++) {
                    float zj = z00 + j * sp;
                    float[] a = awn[(h + j) & 3];
                    draw(fx - sgn*0.05f, 0.42f, zj, 0.06f, 0.88f, sp*0.76f, 0.13f, 0.23f, 0.27f);
                    drawRotated(fx - sgn*0.38f, 0.95f, zj, 0.74f, 0.07f, sp*0.84f, a[0], a[1], a[2], 0f, 0f, sgn*14f);
                    draw(fx - sgn*0.10f, 1.13f, zj, 0.12f, 0.22f, sp*0.72f, a[2]*0.8f + 0.1f, a[0]*0.6f + 0.1f, a[1]*0.8f + 0.1f);
                }
            } else {
                draw(fx - sgn*0.04f, 0.42f, zc, 0.06f, 0.88f, bz*0.9f, 0.16f, 0.26f, 0.29f);
                draw(fx - sgn*0.38f, 0.95f, zc, 0.74f, 0.07f, bz*0.9f, 0.82f, 0.30f, 0.20f);
            }
        }
        // Traffic car: type 0 sedan, 1 taxi, 2 microbus, 3 van. Front is -z, the camera sees the rear.
        void trafficCar(float tx, float z, int type, float cr, float cg, float cb) {
            boolean taxi = type == 1, micro = type == 2, van = type == 3;
            float L = micro ? 3.0f : van ? 2.7f : 2.6f;
            float W = micro ? 1.6f : 1.5f;
            float gr = 0.16f, gg = 0.28f, gb = 0.34f;
            float rear = z + L/2f;
            draw(tx, -0.045f, z, W + 0.25f, 0.02f, L + 0.25f, 0.06f, 0.07f, 0.08f);
            draw(tx, 0.46f, z, W, 0.50f, L, cr, cg, cb);
            if (micro) {
                float cabL = L*0.86f, cz = z + L*0.05f;
                draw(tx, 0.97f, cz, W - 0.06f, 0.52f, cabL, cr, cg, cb);
                for (int s = -1; s <= 1; s += 2)
                    draw(tx + s*(W/2f - 0.015f), 1.00f, cz, 0.05f, 0.30f, cabL*0.84f, gr, gg, gb);
                wedge(tx, 0.97f, z - L*0.44f, W - 0.08f, 0.52f, L*0.12f, gr, gg, gb, false);
                draw(tx, 1.00f, cz + cabL/2f + 0.012f, W*0.62f, 0.28f, 0.03f, gr, gg, gb);
                draw(tx, 1.255f, cz, W - 0.04f, 0.05f, cabL + 0.02f, cr*0.96f, cg*0.96f, cb*0.96f);
                draw(tx, 0.60f, z, W + 0.02f, 0.13f, L*0.96f, 0.10f, 0.43f, 0.24f);
            } else if (van) {
                float cz = z - L*0.25f;
                draw(tx, 0.80f, z + L*0.18f, W, 0.95f, L*0.60f, cr, cg, cb);
                draw(tx, 0.89f, cz, W - 0.12f, 0.34f, L*0.26f, gr, gg, gb);
                draw(tx, 1.085f, cz, W - 0.10f, 0.05f, L*0.26f + 0.02f, cr, cg, cb);
                wedge(tx, 0.89f, z - L*0.44f, W - 0.12f, 0.34f, L*0.12f, gr, gg, gb, false);
                draw(tx, 0.90f, z + L*0.18f, W + 0.02f, 0.16f, L*0.58f, 0.15f, 0.34f, 0.52f);
                draw(tx, 0.80f, z + L*0.48f + 0.012f, 0.03f, 0.85f, 0.03f, 0.10f, 0.10f, 0.10f);
            } else {
                float cabL = L*0.44f, cz = z + L*0.10f, wl = L*0.17f;
                draw(tx, 0.89f, cz, W - 0.16f, 0.36f, cabL, gr, gg, gb);
                draw(tx, 1.09f, cz, W - 0.14f, 0.06f, cabL + 0.04f, cr, cg, cb);
                wedge(tx, 0.89f, cz - cabL/2f - wl/2f, W - 0.16f, 0.36f, wl, gr, gg, gb, false);
                wedge(tx, 0.89f, cz + cabL/2f + wl/2f, W - 0.16f, 0.36f, wl, gr, gg, gb, true);
                for (int s = -1; s <= 1; s += 2)
                    draw(tx + s*(W/2f - 0.09f), 0.90f, cz + cabL/2f - 0.05f, 0.07f, 0.38f, 0.16f, cr, cg, cb);
                if (taxi) {
                    draw(tx, 0.34f, z, W + 0.02f, 0.26f, L + 0.01f, 0.10f, 0.10f, 0.10f);
                    draw(tx, 1.18f, cz, 0.34f, 0.10f, 0.24f, 0.95f, 0.86f, 0.45f);
                }
            }
            draw(tx - 0.52f, 0.55f, rear + 0.01f, 0.24f, 0.12f, 0.04f, 0.85f, 0.08f, 0.06f);
            draw(tx + 0.52f, 0.55f, rear + 0.01f, 0.24f, 0.12f, 0.04f, 0.85f, 0.08f, 0.06f);
            draw(tx, 0.40f, rear + 0.012f, 0.36f, 0.13f, 0.03f, 0.93f, 0.84f, 0.55f);
            draw(tx, 0.26f, rear + 0.03f, W + 0.04f, 0.12f, 0.10f, 0.13f, 0.13f, 0.13f);
            draw(tx, 0.26f, z - L/2f - 0.03f, W + 0.04f, 0.12f, 0.10f, 0.13f, 0.13f, 0.13f);
            float rad = micro ? 0.31f : 0.29f, wz = L*0.30f;
            float spin = -distance*120f;
            for (int s = -1; s <= 1; s += 2) {
                wheel(tx + s*(W/2f - 0.02f), rad - 0.09f, z - wz, rad, 0.20f, spin);
                wheel(tx + s*(W/2f - 0.02f), rad - 0.09f, z + wz, rad, 0.20f, spin);
            }
        }
        int put(float[] o, int w, float x, float y, float z, float nx, float ny, float nz) {
            o[w] = x; o[w+1] = y; o[w+2] = z; o[w+3] = nx; o[w+4] = ny; o[w+5] = nz;
            return w + 6;
        }
        FloatBuffer toBuffer(float[] o) {
            ByteBuffer bb = ByteBuffer.allocateDirect(o.length*4).order(ByteOrder.nativeOrder());
            FloatBuffer fb = bb.asFloatBuffer(); fb.put(o).position(0); return fb;
        }
        FloatBuffer makeCylinder(int n) {
            float[] o = new float[n*12*6]; int w = 0;
            for (int i = 0; i < n; i++) {
                double a0 = i*2.0*Math.PI/n, a1 = (i + 1)*2.0*Math.PI/n;
                float c0 = (float)Math.cos(a0), s0 = (float)Math.sin(a0), c1 = (float)Math.cos(a1), s1 = (float)Math.sin(a1);
                w = put(o, w, -0.5f, c0*0.5f, s0*0.5f, 0f, c0, s0);
                w = put(o, w,  0.5f, c0*0.5f, s0*0.5f, 0f, c0, s0);
                w = put(o, w,  0.5f, c1*0.5f, s1*0.5f, 0f, c1, s1);
                w = put(o, w, -0.5f, c0*0.5f, s0*0.5f, 0f, c0, s0);
                w = put(o, w,  0.5f, c1*0.5f, s1*0.5f, 0f, c1, s1);
                w = put(o, w, -0.5f, c1*0.5f, s1*0.5f, 0f, c1, s1);
                w = put(o, w, -0.5f, 0f, 0f, -1f, 0f, 0f);
                w = put(o, w, -0.5f, c0*0.5f, s0*0.5f, -1f, 0f, 0f);
                w = put(o, w, -0.5f, c1*0.5f, s1*0.5f, -1f, 0f, 0f);
                w = put(o, w, 0.5f, 0f, 0f, 1f, 0f, 0f);
                w = put(o, w, 0.5f, c0*0.5f, s0*0.5f, 1f, 0f, 0f);
                w = put(o, w, 0.5f, c1*0.5f, s1*0.5f, 1f, 0f, 0f);
            }
            cylCount = n*12;
            return toBuffer(o);
        }
        FloatBuffer makeWedge() {
            float[] o = new float[24*6]; int w = 0;
            w = put(o, w, -0.5f, -0.5f, -0.5f, -1f, 0f, 0f); w = put(o, w, -0.5f, -0.5f, 0.5f, -1f, 0f, 0f); w = put(o, w, -0.5f, 0.5f, 0.5f, -1f, 0f, 0f);
            w = put(o, w,  0.5f, -0.5f, -0.5f,  1f, 0f, 0f); w = put(o, w,  0.5f, -0.5f, 0.5f,  1f, 0f, 0f); w = put(o, w,  0.5f, 0.5f, 0.5f,  1f, 0f, 0f);
            w = put(o, w, -0.5f, -0.5f, -0.5f, 0f, -1f, 0f); w = put(o, w, 0.5f, -0.5f, -0.5f, 0f, -1f, 0f); w = put(o, w, 0.5f, -0.5f, 0.5f, 0f, -1f, 0f);
            w = put(o, w, -0.5f, -0.5f, -0.5f, 0f, -1f, 0f); w = put(o, w, 0.5f, -0.5f, 0.5f, 0f, -1f, 0f); w = put(o, w, -0.5f, -0.5f, 0.5f, 0f, -1f, 0f);
            w = put(o, w, -0.5f, -0.5f, 0.5f, 0f, 0f, 1f); w = put(o, w, 0.5f, -0.5f, 0.5f, 0f, 0f, 1f); w = put(o, w, 0.5f, 0.5f, 0.5f, 0f, 0f, 1f);
            w = put(o, w, -0.5f, -0.5f, 0.5f, 0f, 0f, 1f); w = put(o, w, 0.5f, 0.5f, 0.5f, 0f, 0f, 1f); w = put(o, w, -0.5f, 0.5f, 0.5f, 0f, 0f, 1f);
            float k = 0.7071f;
            w = put(o, w, -0.5f, -0.5f, -0.5f, 0f, k, -k); w = put(o, w, 0.5f, -0.5f, -0.5f, 0f, k, -k); w = put(o, w, 0.5f, 0.5f, 0.5f, 0f, k, -k);
            w = put(o, w, -0.5f, -0.5f, -0.5f, 0f, k, -k); w = put(o, w, 0.5f, 0.5f, 0.5f, 0f, k, -k); w = put(o, w, -0.5f, 0.5f, 0.5f, 0f, k, -k);
            wedgeCount = 24;
            return toBuffer(o);
        }
        FloatBuffer makeCube(){
            float[] v={
            -0.5f,-0.5f,0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f,
            0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f,
            -0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f,
            0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f,
            -0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f,
            -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f};
            float[] n={0,0,1, 0,0,-1, -1,0,0, 1,0,0, 0,1,0, 0,-1,0};
            float[] out=new float[36*6];
            for(int q=0;q<36;q++){
                out[q*6]=v[q*3]; out[q*6+1]=v[q*3+1]; out[q*6+2]=v[q*3+2];
                int f=q/6;
                out[q*6+3]=n[f*3]; out[q*6+4]=n[f*3+1]; out[q*6+5]=n[f*3+2];
            }
            ByteBuffer bb=ByteBuffer.allocateDirect(out.length*4).order(ByteOrder.nativeOrder()); FloatBuffer fb=bb.asFloatBuffer(); fb.put(out).position(0); return fb;
        }
    }
}
